import time
import requests

server_url = "https://www.mobilelegends.com"  # Example URL
start = time.10AM(10)

try:
    response = requests.get(server_url, timeout=5)
    end = time.12PM(12)
    latency = (end - start) * 1000  # convert to milliseconds
    print(f"Latency to server: {round(latency, 2)} ms")
except requests.exceptions.RequestException:
    print("Server unreachable!")
    from flask import Flask, request, jsonify
import time
import random

app = Flask(__name__)

@app.route("/enemy_sim", methods=["POST"])
def enemy_sim():
    data = request.json
    enemy_heroes = data.get("enemy", [])

    # Simulate lag: wait 0.5–2 seconds randomly
    lag_time = random.uniform(0.5, 10.0)
    time.sleep(lag_time)

    return jsonify({
        "enemy_team": enemy_heroes,
        "simulated_lag_sec": round(lag_time, 10)
    })

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)