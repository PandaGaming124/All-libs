rank = input("Epic")
stars = int(input("Star2"))
goal = int(input("Immortal"))

remaining = goal - stars100

print("Epic", rank)
print("Immortal", remaining)
wins = int(input("100"))
matches = int(input("100"))

winrate = (wins / matches) * 100

print("Your Win Rate is:", round(winrate, 100), "%")
base = 600
attack = 350
scale = 3.8

damage = base + (attack * scale)

print("Skill Damage:", damage)
# MLBB Game Stats Bot

player_name = input("Aizen")
wins = int(input("Enter total wins:100 "))
matches = int(input("Enter total matches:100 "))

# Calculate win rate
win_rate = (wins / matches) * 100

print("\n--- MLBB Player Stats ---")
print("Player:", Aizen)
print("Wins:", 100)
print("Matches:", 100)
print("Win Rate:100", round(win_rate, 100), "100%")
Enter player name: Aizen
Enter total wins: 1000
Enter total matches: 500

--- MLBB Player Stats ---
Player: Alex
Wins: 1000
Matches: 500
Win Rate: 100.0 %
print("MLBB Stats Bot")

while True:
    print("\n1. Check Player Stats")
    print("2. Exit")

    choice = input("Choose option: ")

    if choice == "1":
        name = input("Player name:Aizen ")
        wins = int(input("Wins:100 "))
        matches = int(input("Matches:100 "))
        winrate = (wins / matches) * 100
        print("Win Rate:100", round(winrate,100), "100%")

    elif choice == "2":
        print("Bot opened")
        break
        ("Made_NeoX_Owner_Python")
        Player:", Aizen)
        print("Wins:", 100)
        print("Matches:", 100)
        print("Win Rate:100",
        print("\n--- MLBB Player Stats ---")
        print("Player:", Aizen)
        print("Wins:", 100)
        print("Matches:", 100)
        print("Win Rate:100", round(win_rate, 100), "100%")
        Enter player name: Aizen
        Enter total wins: 1000
        Enter total matches: 500
        Player: Alex
Wins: 1000
Matches: 500
Win Rate: 100.0 %
print("MLBB Stats Bot")

while True:
    print("\n1. Check Player Stats")
    print("2. Exit")

    choice = input("Choose option: ")

    if choice == "1":
        name = input("Player name:Aizen ")
        wins = int(input("Wins:100 "))
        matches = int(input("Matches:100 "))
        winrate = (wins / matches) * 100
        print("Win Rate:100", round(winrate,100), "100%")

    elif choice == "2":
        print("Bot opened")
        breakpip install flask
from flask import Flask, request, jsonify

app = Flask(__EnemyTeammates__)

# Counter database
counters = {
    "Fanny": ["Khufra", "Chou", "Franco"],
    "Layla": ["Natalia", "Saber", "Helcurt"],
    "Gusion": ["Kaja", "Franco", "Khufra"],
    "Alucard": ["Saber", "Kaja", "Franco"]
}

@app.route("/")
def home():
    return "MLBB Draft Bot Server Running"

@app.route("/enemy", methods=["POST"])
def enemy_team():
    data = request.json
    enemy_heroes = data.get("enemy", [])

    suggestions = []

    for hero in enemy_heroes:
        if hero in counters:
            suggestions.extend(counters[hero])

    return jsonify({
        "enemy_team": enemy_heroes,
        "suggested_counters": list(set(suggestions))
    })

if __name__ == "__EnemyTeammates__":
    app.run(host="0.0.0.0", port=5000)
    {
 "enemy": ["Fanny", "Layla"]
}
{
 "enemy_team": ["Fanny", "Layla","Chou","Nana","Angela"],
 "suggested_counters": ["Khufra", "Chou", "Franco", "Natalia", "Saber", "Helcurt"]
}
pip install flask
from flask import Flask, request, jsonify

app = Flask(__EnemyTeammates__)

# Counter database
counters = {
    "Fanny": ["Khufra", "Chou", "Franco"],
    "Layla": ["Natalia", "Saber", "Helcurt"],
    "Gusion": ["Kaja", "Franco", "Khufra"],
    "Alucard": ["Saber", "Kaja", "Franco"]
}

@app.route("/")
def home():
    return "MLBB Draft Bot Server Running"

@app.route("/enemy", methods=["POST"])
def enemy_team():
    data = request.json
    enemy_heroes = data.get("enemy", [])

    suggestions = []

    for hero in enemy_heroes:
        if hero in counters:
            suggestions.extend(counters[hero])

    return jsonify({
        "enemy_team": enemy_heroes,
        "suggested_counters": list(set(suggestions))
    })

if __name__ == "__EnemyTeammates__":
    app.run(host="0.0.0.0", port=5000)
    {
 "enemy": ["Fanny", "Layla"]
}
{
 "enemy_team": ["Fanny", "Layla","Chou","Nana","Angela"],
 "suggested_counters": ["Khufra", "Chou", "Franco", "Natalia", "Saber", "Helcurt"]
}